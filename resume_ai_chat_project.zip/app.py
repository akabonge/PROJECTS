from flask import Flask, request, jsonify, render_template
import openai

app = Flask(__name__)

# Set your OpenAI API Key
OPENAI_API_KEY = "your-openai-api-key-here"
MODEL_NAME = "ft:gpt-3.5-turbo-1106:resume-ai::B9iHxXLm"

client = openai.OpenAI(api_key=OPENAI_API_KEY)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "").strip()

    if not user_message:
        return jsonify({"error": "Message is required."}), 400

    try:
        response = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {"role": "system", "content":
                 "You are a career coach and resume expert. Your primary goal is to assist individuals with job applications, resume optimization, career guidance, interview strategies, and professional networking. If a user asks something unrelated to career development, politely redirect them."},
                {"role": "user", "content": user_message}
            ],
            temperature=0.7,
            max_tokens=500
        )

        reply = response.choices[0].message.content
        return jsonify({"reply": reply})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=False)
